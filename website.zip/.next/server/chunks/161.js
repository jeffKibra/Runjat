"use strict";
exports.id = 161;
exports.ids = [161];
exports.modules = {

/***/ 5098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ CREATE_COMMENT),
/* harmony export */   "m": () => (/* binding */ GET_RECENT_COMMENTS)
/* harmony export */ });
const CREATE_COMMENT = "CREATE_COMMENT";
const GET_RECENT_COMMENTS = "GET_RECENT_COMMENTS";


/***/ }),

/***/ 2487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BL": () => (/* binding */ start),
/* harmony export */   "Vp": () => (/* binding */ success),
/* harmony export */   "H5": () => (/* binding */ commentsSuccess),
/* harmony export */   "bG": () => (/* binding */ fail),
/* harmony export */   "mc": () => (/* binding */ reset),
/* harmony export */   "EG": () => (/* binding */ commentsReducer)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    loading: false,
    isModified: false,
    comments: null,
    error: null,
    action: null
};
const commentsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "comments_slice",
    initialState: {
        ...initialState
    },
    reducers: {
        start: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                loading: true,
                error: null,
                action: payload
            };
        },
        success: (state)=>{
            return {
                ...state,
                loading: false,
                isModified: true
            };
        },
        commentsSuccess: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                loading: false,
                comments: payload
            };
        },
        fail: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                loading: false,
                error: payload
            };
        },
        reset: ()=>{
            return {
                ...initialState
            };
        }
    }
});
const { start , success , commentsSuccess , fail , reset  } = commentsSlice.actions;
const commentsReducer = commentsSlice.reducer;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (commentsSlice)));


/***/ })

};
;