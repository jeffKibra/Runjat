"use strict";
exports.id = 225;
exports.ids = [225];
exports.modules = {

/***/ 3359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ SEND_EMAIL)
/* harmony export */ });
const SEND_EMAIL = "SEND_EMAIL";


/***/ }),

/***/ 754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BL": () => (/* binding */ start),
/* harmony export */   "Vp": () => (/* binding */ success),
/* harmony export */   "bG": () => (/* binding */ fail),
/* harmony export */   "mc": () => (/* binding */ reset),
/* harmony export */   "C9": () => (/* binding */ contactReducer)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    loading: false,
    isSent: false,
    error: null
};
const contactSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "contact_slice",
    initialState: {
        ...initialState
    },
    reducers: {
        start: (state)=>{
            return {
                ...state,
                loading: true,
                error: null
            };
        },
        success: (state)=>{
            return {
                ...state,
                loading: false,
                isSent: true
            };
        },
        fail: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                loading: false,
                error: payload
            };
        },
        reset: ()=>{
            return {
                ...initialState
            };
        }
    }
});
const { start , success , fail , reset  } = contactSlice.actions;
const contactReducer = contactSlice.reducer;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (contactSlice)));


/***/ })

};
;