"use strict";
exports.id = 558;
exports.ids = [558];
exports.modules = {

/***/ 5682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "db": () => (/* binding */ db)
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// import { getAnalytics, isSupported } from "firebase/analytics";
const firebaseConfig = {
    apiKey: "AIzaSyBxuaL5LfExvMrPj_hcBQZtg6gGnZ4GAcc",
    authDomain: "finitecr-blogs.firebaseapp.com",
    projectId: "finitecr-blogs",
    storageBucket: "finitecr-blogs.appspot.com",
    messagingSenderId: "601844151897",
    appId: "1:601844151897:web:b2acb95c8c25959be96348",
    measurementId: "G-Z3F7TFRRYW"
};
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore)(app); // const isWeb = await isSupported();
 // let analytics_ = null;
 // if (isWeb) {
 //   analytics_ = getAnalytics(app);
 // }
 // export const analytics = analytics_;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1843:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ formatArticle)
/* harmony export */ });
function convertToDate(timestamp) {
    return `${new Date(timestamp.seconds)}`;
}
function formatArticle(article) {
    const { createdAt , modifiedAt  } = article;
    return {
        ...article,
        createdAt: convertToDate(createdAt),
        modifiedAt: convertToDate(modifiedAt)
    };
};


/***/ }),

/***/ 2818:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getActiveArticles)
/* harmony export */ });
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1492);
/* harmony import */ var _constants_firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5682);
/* harmony import */ var _formatArticle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function getActiveArticles() {
    const blogId = "qCEU8T48srbT2zBaOE2Q";
    const q = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_1__.db, "blogs", blogId, "articles"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.orderBy)("createdAt", "desc"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where)("status", "==", "active"));
    const snap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocs)(q);
    const articles = [];
    snap.forEach((articleDoc)=>{
        articles.push((0,_formatArticle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
            ...articleDoc.data(),
            articleId: articleDoc.id
        }));
    });
    return articles;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3876:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getArticle)
/* harmony export */ });
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1492);
/* harmony import */ var _constants_firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5682);
/* harmony import */ var _formatArticle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function getArticle(slug) {
    const blogId = "qCEU8T48srbT2zBaOE2Q";
    const q = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_1__.db, "blogs", blogId, "articles"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where)("slug", "==", slug), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.limit)(1));
    const snap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocs)(q);
    const articleDoc = snap.docs[0];
    //   let article = {
    //     title: "article not found!",
    //     content: "Please ensure you got the correct article slug",
    //     pageTitle: "Article not found!",
    //     pageDescription: "",
    //   };
    if (articleDoc.exists) {
        return (0,_formatArticle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
            ...articleDoc.data(),
            articleId: articleDoc.id
        });
    }
    return null;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9638:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getRecentComments)
/* harmony export */ });
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1492);
/* harmony import */ var _constants_firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5682);
/* harmony import */ var _formatArticle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function getRecentComments(articleId) {
    const blogId = "qCEU8T48srbT2zBaOE2Q";
    const q = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_1__.db, "blogs", blogId, "articles", articleId, "comments"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.orderBy)("createdAt", "desc"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where)("status", "==", "active"));
    const snap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocs)(q);
    const comments = [];
    snap.forEach((commentDoc)=>{
        comments.push((0,_formatArticle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
            ...commentDoc.data(),
            articleId: commentDoc.id
        }));
    });
    return comments;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getRelatedArticles)
/* harmony export */ });
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1492);
/* harmony import */ var _constants_firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5682);
/* harmony import */ var _formatArticle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_0__, _constants_firebase__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function getRelatedArticles(categoriesIds, articleId) {
    const blogId = "qCEU8T48srbT2zBaOE2Q";
    const q = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_1__.db, "blogs", blogId, "articles"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.orderBy)("createdAt", "desc"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where)("categoriesIds", "array-contains-any", categoriesIds), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where)("status", "==", "active"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.limit)(6));
    const snap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocs)(q);
    const articles = [];
    snap.forEach((articleDoc)=>{
        articles.push((0,_formatArticle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
            ...articleDoc.data(),
            articleId: articleDoc.id
        }));
    });
    return articles.filter((article)=>article.articleId !== articleId
    );
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jh": () => (/* reexport safe */ _getActiveArticles__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "fq": () => (/* reexport safe */ _getArticle__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "uA": () => (/* reexport safe */ _getRecentComments__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "eA": () => (/* reexport safe */ _getRelatedArticles__WEBPACK_IMPORTED_MODULE_3__.Z)
/* harmony export */ });
/* harmony import */ var _getActiveArticles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2818);
/* harmony import */ var _getArticle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3876);
/* harmony import */ var _getRecentComments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9638);
/* harmony import */ var _getRelatedArticles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9458);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_getActiveArticles__WEBPACK_IMPORTED_MODULE_0__, _getArticle__WEBPACK_IMPORTED_MODULE_1__, _getRecentComments__WEBPACK_IMPORTED_MODULE_2__, _getRelatedArticles__WEBPACK_IMPORTED_MODULE_3__]);
([_getActiveArticles__WEBPACK_IMPORTED_MODULE_0__, _getArticle__WEBPACK_IMPORTED_MODULE_1__, _getRecentComments__WEBPACK_IMPORTED_MODULE_2__, _getRelatedArticles__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;