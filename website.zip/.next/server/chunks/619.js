"use strict";
exports.id = 619;
exports.ids = [619];
exports.modules = {

/***/ 2619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ constants_servicesList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
;// CONCATENATED MODULE: ./public/statics/images/recruitment.png
/* harmony default export */ const recruitment = ({"src":"/_next/static/media/recruitment.faee9dc7.png","height":572,"width":858,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAXVBMVEWeuN6Qd2razc6hgIG9tsdwdXzF0MWnssKJrOOYqcCOmq9KS0x6hp/h0tS0mo/V5NlYXWOKocLd3PGqsdp6d3jz1duqvuSfj3/IyLbZvcWpttHZuK/DyNuvnpRZW1ivVHFnAAAAE3RSTlP8+v76/v76/Pz8+v7+/v7+/v7+GKj8FAAAAAlwSFlzAAALEwAACxMBAJqcGAAAADVJREFUCJlj4OJgZ+ZkYGNkEJaSFBUTkxBnEOYU5eVh52dikJYRYpHjFhBhYGHgEJTlE2EFADBRAkCPIK+nAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/statics/images/leadership.jpg
/* harmony default export */ const leadership = ({"src":"/_next/static/media/leadership.0ede8776.jpg","height":428,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAeEAABBAIDAQAAAAAAAAAAAAABAAIDBAURBiFhof/EABUBAQEAAAAAAAAAAAAAAAAAAAUG/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQACIRL/2gAMAwEAAhEDEQA/AJ/GsdRmbkn2o5JjDUdK0F+gNEdj34iImDLISeXrWf/Z"});
;// CONCATENATED MODULE: ./public/statics/images/health.jpg
/* harmony default export */ const health = ({"src":"/_next/static/media/health.6f03c347.jpg","height":299,"width":449,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAFAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAeEAACAQMFAAAAAAAAAAAAAAABAgADERMFEkGRof/EABQBAQAAAAAAAAAAAAAAAAAAAAT/xAAbEQABBAMAAAAAAAAAAAAAAAACAAEDMRETYf/aAAwDAQACEQMRAD8AqstR9LzKwQlgAAON1jfr2IiLism6iTAOsHxbL//Z"});
;// CONCATENATED MODULE: ./public/statics/images/payroll.jpg
/* harmony default export */ const payroll = ({"src":"/_next/static/media/payroll.54a7ef52.jpg","height":427,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAP/xAAdEAACAgIDAQAAAAAAAAAAAAABAgADBREEBiEx/8QAFAEBAAAAAAAAAAAAAAAAAAAAA//EABcRAQEBAQAAAAAAAAAAAAAAAAECACH/2gAMAwEAAhEDEQA/AJ8fC2J19sS9laq4UhkXZRWO9An0/IiIF2jzJMid3//Z"});
;// CONCATENATED MODULE: ./public/statics/images/feedback.jpg
/* harmony default export */ const feedback = ({"src":"/_next/static/media/feedback.712f0eaa.jpg","height":427,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAaEAACAwEBAAAAAAAAAAAAAAAAAQIDERNB/8QAFQEBAQAAAAAAAAAAAAAAAAAAAgP/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCqprkpZ1eLzEAAqP/Z"});
;// CONCATENATED MODULE: ./public/statics/images/law.jpg
/* harmony default export */ const law = ({"src":"/_next/static/media/law.72977f7c.jpg","height":932,"width":640,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAUDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAH/xAAfEAABAwMFAAAAAAAAAAAAAAABAAIDBAURBhIhUWH/xAAVAQEBAAAAAAAAAAAAAAAAAAAAAv/EABURAQEAAAAAAAAAAAAAAAAAAAEA/9oADAMBAAIRAxEAPwC6ivNFFWR091MUD4YmsY0O35GBzkAd+oiILShf/9k="});
;// CONCATENATED MODULE: ./constants/servicesList.js


//images






const servicesList = [
    {
        title: "RECRUITMENT AND SELECTION",
        id: "recruitment",
        image: {
            src: recruitment,
            alt: "recruitment and selection"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            fontSize: "md",
            children: "IFHCC helps organization; large, medium or small corporations to help meet its dream of getting the right player into their team. This is the right point of entry of employee and getting the right candidate makes all the difference including cost cutting. It is easy to train, develop and compensate the right candidate than it is to put efforts to a wrong or wrong recruited candidate. Therefore, making is very crucial to involve us to help you get it right first time. IFHCC acts as middleman between your company and the right candidate with the right talent, skills, experience and attitude."
        })
    },
    {
        title: "INDUCTION PERIOD AND CONFIGURING PRESENT AND FUTURE CONDITION OF THE EMPLOYEE",
        id: "induction",
        image: {
            src: leadership,
            alt: "induction"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            children: "IFHCC helps with setting the standards with both the selected candidate as well as with the existing staff. For incoming staff, induction is key to ensure the candidate understands rules of operations plus his job description. At the same time, IFHCC helps organizations with offering training, development and coaching to existing employees. For organization to stand the test of time and remain competitive, employees have to be trained and development continuously so as to keep them focused on the strategic objective of the organization. IFHCC helps organization identify training needs, help design training content and identify training methods and ways to rate the impact through productivity."
        })
    },
    {
        title: "PROFESSIONAL HEALTH AND SAFETY",
        id: "professional-health",
        image: {
            src: health,
            alt: "heath and safety"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            children: "IFHCC helps the organization to understand that it is for the its benefit to have a healthy workforce thus help foster same and a the same mitigating threats that might hinder health and safety. IFHCC also helps employees to understand and embrace a healthy lifestyle. Studies show that employees are more productive when healthy and safe. Our job is help organization realize this."
        })
    },
    {
        title: "COMPENSATION, BENEFITS AND PAYROLL",
        id: "compensation",
        image: {
            src: payroll,
            alt: "compensation"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            children: "IFHCC helps organization come up with structured method or matrix on how to reward and compensate its employees. It is crucial for an employer to understand the rationale behind the payroll including other benefits such as bonuses, cautionary funds, retirement benefits plus any other discretionally benefits. Issue of money and payroll particularly the set payroll date should be very clear to employees. While there are other ways to appreciate employees, payroll is the most key and should be honored if a good relationship between the employer and the employee is to be maintained."
        })
    },
    {
        title: "HONEST APPRAISALS AND OTHER FORMS OF FEEDBACK",
        id: "appraisals",
        image: {
            src: feedback,
            alt: "feedback"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            children: "Occasionally, employees might feel appraisal process was not fair and just. IFHCC helps organizations to help with objective appraisals and feedback through assessing the process of setting quantitative goals and objectives and making employees cognizant of the standards and ultimately evaluating the staff in respect to this process. A honest and objective appraisal and feedback is not only good for the staff to also for the organization."
        })
    },
    {
        title: "LABOUR LAWS",
        id: "labour-laws",
        image: {
            src: law,
            alt: "labour laws"
        },
        content: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
            children: "Mastering labor laws can be tedious for a HR department and so IFHCC company can help offer labor law consultancy through our experts. This can be done by either direct consultancy or helping set a compliance section within your HR department so as to be compliant to the laid down employment guidelines and other related laws. Being compliant will save unseen unnecessary cost as well save brand image."
        })
    }, 
];
/* harmony default export */ const constants_servicesList = (servicesList);


/***/ })

};
;