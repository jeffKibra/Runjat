"use strict";
exports.id = 954;
exports.ids = [954];
exports.modules = {

/***/ 1954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_PageBanner)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: ./components/layout/nav/index.jsx + 5 modules
var nav = __webpack_require__(9901);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/ui/BackgroundImage.jsx




function BackgroundImage(props) {
    const { src , imageTitle , children , objectFit  } = props;
    console.log({
        objectFit
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
        position: "relative",
        h: "100vh",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                zIndex: -1,
                h: "full",
                w: "full",
                position: "absolute",
                top: 0,
                left: 0,
                opacity: 1,
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    style: {
                        zIndex: 0
                    },
                    src: src,
                    alt: imageTitle,
                    layout: "fill",
                    objectPosition: "center",
                    objectFit: objectFit,
                    priority: true
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                position: "absolute",
                top: 0,
                left: 0,
                h: "full",
                w: "full",
                backgroundColor: "#303030",
                opacity: 0.5
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                flexGrow: 1,
                position: "relative",
                zIndex: 9,
                h: "full",
                w: "full",
                children: children
            })
        ]
    });
}
BackgroundImage.defaultProps = {
    objectFit: "cover"
};
BackgroundImage.propTypes = {
    src: (external_prop_types_default()).any.isRequired,
    imageTitle: (external_prop_types_default()).string.isRequired,
    children: (external_prop_types_default()).node.isRequired,
    objectFit: external_prop_types_default().oneOf([
        "cover",
        "contain",
        "fill",
        "none",
        "scale-down", 
    ])
};
/* harmony default export */ const ui_BackgroundImage = (BackgroundImage);

;// CONCATENATED MODULE: ./components/layout/PageBanner.jsx





function PageBanner(props) {
    const { image: { src , title  } , objectFit , children ,  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(ui_BackgroundImage, {
        objectFit: objectFit,
        src: src,
        imageTitle: title,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
            w: "full",
            h: "full",
            direction: "column",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(nav/* default */.Z, {}),
                children
            ]
        })
    });
}
PageBanner.propTypes = {
    image: external_prop_types_default().shape({
        src: (external_prop_types_default()).any.isRequired,
        title: (external_prop_types_default()).string.isRequired
    }),
    children: (external_prop_types_default()).node.isRequired,
    objectFit: external_prop_types_default().oneOf([
        "cover",
        "contain",
        "fill",
        "none",
        "scale-down", 
    ])
};
/* harmony default export */ const layout_PageBanner = (PageBanner);


/***/ })

};
;