"use strict";
exports.id = 969;
exports.ids = [969];
exports.modules = {

/***/ 4048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_PageLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
;// CONCATENATED MODULE: ./components/layout/ScrollButton.jsx




function ScrollButton() {
    const { 0: visible , 1: setVisibility  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        function handleScroll() {
            if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
                setVisibility(true);
            } else {
                setVisibility(false);
            }
        }
        window.onscroll = function() {
            handleScroll();
        };
    }, []);
    // When the user clicks on the button, scroll to the top of the document
    function scrollToTop() {
        document.body.scrollTop = 0; // For Safari
        document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
    }
    return visible ? /*#__PURE__*/ jsx_runtime_.jsx(react_.IconButton, {
        zIndex: 1000,
        colorScheme: "cyan",
        fontSize: "2xl",
        position: "fixed",
        bottom: "50",
        right: "30",
        onClick: scrollToTop,
        icon: /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiArrowUpSLine, {})
    }) : null;
}
/* harmony default export */ const layout_ScrollButton = (ScrollButton);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./constants/routes.js
var routes = __webpack_require__(4757);
// EXTERNAL MODULE: ./constants/contacts.js
var contacts = __webpack_require__(4412);
;// CONCATENATED MODULE: ./components/layout/SubFooter.jsx






function SubFooter() {
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        bg: "rgba(0,0,0,0.8)",
        pt: "40px",
        color: "white",
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
            maxW: "container.lg",
            p: "24px",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Grid, {
                columnGap: 6,
                templateColumns: "repeat(12, 1fr)",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                        mb: "20px",
                        colSpan: [
                            12,
                            4
                        ],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                as: "h4",
                                pb: "8px",
                                size: "sm",
                                children: "CONTACT INFORMATION"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "5px",
                                w: "150px",
                                bg: "pink"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                pt: "8px",
                                size: "sm",
                                children: "Name"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "2px",
                                w: "40px",
                                bg: "pink"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                pt: "8px",
                                children: contacts/* default.name */.Z.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                pt: "8px",
                                size: "sm",
                                children: "Address"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "2px",
                                w: "55px",
                                bg: "pink"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                pt: "8px",
                                children: contacts/* default.address */.Z.address
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                pt: "8px",
                                size: "sm",
                                children: "Phone"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "2px",
                                w: "40px",
                                bg: "pink"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                pt: "8px",
                                children: contacts/* default.phone */.Z.phone
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                pt: "8px",
                                size: "sm",
                                children: "Email"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "2px",
                                w: "35px",
                                bg: "pink"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                pt: "8px",
                                children: contacts/* default.email */.Z.email
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                        mb: "20px",
                        colSpan: [
                            12,
                            4
                        ],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                as: "h4",
                                pb: "8px",
                                size: "sm",
                                children: "QUICK LINKS"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "5px",
                                w: "100px",
                                bg: "yellow"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.List, {
                                children: routes/* default.map */.ZP.map((route, i)=>{
                                    const { href , name  } = route;
                                    return /*#__PURE__*/ jsx_runtime_.jsx(react_.ListItem, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(QuickLink, {
                                            href: href,
                                            children: name
                                        })
                                    }, i);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                        mb: "20px",
                        colSpan: [
                            12,
                            4
                        ],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                as: "h4",
                                pb: "8px",
                                size: "sm",
                                children: "LET'S CONNECT"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                h: "5px",
                                w: "90px",
                                bg: "blue"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.List, {
                                mt: "8px",
                                children: socials.map((social, i)=>{
                                    const { name , icon , href  } = social;
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.ListItem, {
                                        display: "flex",
                                        alignItems: "center",
                                        mb: "8px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.ListIcon, {
                                                fontSize: "4xl",
                                                as: icon
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                                href: href,
                                                target: "_blank",
                                                children: name
                                            })
                                        ]
                                    }, i);
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}
const socials = [
    {
        name: "Facebook",
        icon: ri_.RiFacebookBoxFill,
        bg: "facebook.900",
        href: "/"
    },
    {
        name: "Twitter",
        icon: ri_.RiTwitterFill,
        bg: "twitter",
        href: contacts/* default.twitter */.Z.twitter
    },
    {
        name: "Linkedin",
        icon: ri_.RiLinkedinBoxFill,
        bg: "linkedin",
        href: contacts/* default.linkedIn */.Z.linkedIn
    }, 
];
/* harmony default export */ const layout_SubFooter = (SubFooter);
function QuickLink(props) {
    const { href , children  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
        pb: "8px",
        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
            href: href,
            passHref: true,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                children: children
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/layout/Footer.jsx



function Footer(props) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(layout_SubFooter, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                h: "70px",
                bg: "black",
                color: "white",
                justifyContent: "center",
                alignItems: "center",
                children: [
                    "Copyright \xa9 2022",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                        ml: "4",
                        href: "https://finitecreations.co.ke",
                        target: "_blank",
                        children: "Finite Creations"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const layout_Footer = (Footer);

;// CONCATENATED MODULE: ./components/layout/PageLayout.jsx





function PageLayout(props) {
    const { pageTitle , pageDescription , children  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: pageTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: pageDescription
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "robots",
                        content: "index, follow"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: pageTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:description",
                        content: pageDescription
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "https://ignatiusfactorhrconsulting.com"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:site_name",
                        content: "ignatius factor HR consulting"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:title",
                        content: pageTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:description",
                        content: pageDescription
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:site",
                        content: "@ignatius_factor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:creator",
                        content: "@ignatius_factor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "apple-touch-icon",
                        sizes: "180x180",
                        href: "/apple-touch-icon.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "32x32",
                        href: "/favicon-32x32.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "16x16",
                        href: "/favicon-16x16.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "manifest",
                        href: "/manifest.json"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout_ScrollButton, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout_Footer, {})
        ]
    });
}
PageLayout.propTypes = {
    children: (external_prop_types_default()).node.isRequired,
    pageTitle: (external_prop_types_default()).string.isRequired,
    pageDescription: (external_prop_types_default()).string
};
/* harmony default export */ const layout_PageLayout = (PageLayout);


/***/ }),

/***/ 9901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ nav)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./constants/routes.js
var routes = __webpack_require__(4757);
;// CONCATENATED MODULE: ./components/layout/nav/NormalLinks.jsx




function NormalLinks() {
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
        display: [
            "none",
            "none",
            "none",
            "flex"
        ],
        alignItems: "center",
        children: routes/* default.map */.ZP.map((route, i, arr)=>{
            const { href , name  } = route;
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                h: "full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: href,
                        passHref: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Link, {
                            pl: "24px",
                            pr: "24px",
                            display: "flex",
                            alignItems: "center",
                            h: "full",
                            children: [
                                name,
                                " "
                            ]
                        })
                    }),
                    i < arr.length - 1 && /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                        width: "1px",
                        h: "60%",
                        bg: "white"
                    })
                ]
            }, i);
        })
    });
}
/* harmony default export */ const nav_NormalLinks = (NormalLinks);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
;// CONCATENATED MODULE: ./components/layout/nav/MobileMenu.jsx






function MobileMenu() {
    const { isOpen , onOpen , onClose  } = (0,react_.useDisclosure)();
    const btnRef = (0,external_react_.useRef)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        display: [
            "block",
            "block",
            "block",
            "none"
        ],
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.IconButton, {
                ref: btnRef,
                icon: /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiMenu3Fill, {}),
                variant: "outline",
                fontSize: "xl",
                onClick: onOpen
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Drawer, {
                isOpen: isOpen,
                placement: "top",
                onClose: onClose,
                finalFocusRef: btnRef,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.DrawerOverlay, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.DrawerContent, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.DrawerCloseButton, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.DrawerBody, {
                                children: routes/* default.map */.ZP.map((route, i, arr)=>{
                                    const { href , name  } = route;
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                                        direction: "column",
                                        alignItems: "center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: href,
                                                passHref: true,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Link, {
                                                    p: "12px",
                                                    display: "flex",
                                                    alignItems: "center",
                                                    justifyContent: "center",
                                                    w: "full",
                                                    h: "full",
                                                    _hover: {
                                                        bg: "rgba(0,0,0,0.1)"
                                                    },
                                                    children: [
                                                        name,
                                                        " "
                                                    ]
                                                })
                                            }),
                                            i < arr.length - 1 && /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                                h: "1px",
                                                width: "80%",
                                                bg: "cyan"
                                            })
                                        ]
                                    }, i);
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const nav_MobileMenu = (MobileMenu);

;// CONCATENATED MODULE: ./public/statics/images/ignatiusLogo.png
/* harmony default export */ const ignatiusLogo = ({"src":"/_next/static/media/ignatiusLogo.72c1ea4f.png","height":541,"width":2878,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAADFBMVEUjh5yKyuIWlbxKsdm3OFWuAAAABHRSTlNbY0ZdVvdeigAAAAlwSFlzAAALEwAACxMBAJqcGAAAAA5JREFUCJljYGRmAAEmAAAoAAcIXI9SAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/layout/nav/Nav.jsx







//logo image

function Nav() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
        color: "white",
        pl: [
            "8px",
            "24px"
        ],
        pr: [
            "8px",
            "24px"
        ],
        alignItems: "center",
        height: "80px",
        borderBottom: "1px white solid",
        as: "nav",
        maxW: "100vw",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                h: "60px",
                w: [
                    "250px",
                    "300px"
                ],
                _hover: {
                    cursor: "pointer"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: routes/* HOME */.Sd,
                    passHref: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                        src: ignatiusLogo,
                        alt: "ignatius factor hr logo",
                        height: 3508,
                        width: 549
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                flexGrow: 1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(nav_NormalLinks, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(nav_MobileMenu, {})
        ]
    });
}
/* harmony default export */ const nav_Nav = (Nav);

;// CONCATENATED MODULE: ./components/layout/nav/SlideDownNav.jsx




function SlideDownNav() {
    const { 0: top , 1: setTop  } = (0,external_react_.useState)(-60);
    (0,external_react_.useEffect)(()=>{
        window.onscroll = function() {
            handleScroll();
        };
        function handleScroll() {
            if (document.body.scrollTop > 60 || document.documentElement.scrollTop > 60) {
                setTop(0);
            } else {
                setTop(-60);
            }
        }
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        width: "full",
        height: "80px",
        position: "fixed",
        top: top,
        left: 0,
        transition: "top 0.5s",
        bg: "rgba(0,0,0,0.9)",
        zIndex: 999,
        children: /*#__PURE__*/ jsx_runtime_.jsx(nav_Nav, {})
    });
}
/* harmony default export */ const nav_SlideDownNav = (SlideDownNav);

;// CONCATENATED MODULE: ./components/layout/nav/index.jsx



function NavBar() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(nav_Nav, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(nav_SlideDownNav, {})
        ]
    });
}
/* harmony default export */ const nav = (NavBar);


/***/ }),

/***/ 4412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contacts = {
    name: "Ignatius Factor HR Consulting",
    address: "P.O. Box 35684-00200 NAIROBI",
    phone: "+254 740 897 756",
    email: "info@ignatiusfactorhrconsulting.com",
    facebook: "",
    twitter: "https://twitter.com/ignatius_factor",
    linkedIn: "https://linkedin.com/in/ignatius-factor-884462236/"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contacts);


/***/ }),

/***/ 4757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Sd": () => (/* binding */ HOME),
/* harmony export */   "uv": () => (/* binding */ WHO_WE_ARE),
/* harmony export */   "bk": () => (/* binding */ OUR_SERVICES),
/* harmony export */   "Kp": () => (/* binding */ GET_IN_TOUCH),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export BLOG */
const HOME = "/";
const WHO_WE_ARE = "/who-we-are";
const OUR_SERVICES = "/our-services";
const GET_IN_TOUCH = "/get-in-touch";
const BLOG = "/blog";
const routes = [
    {
        href: HOME,
        name: "Home"
    },
    {
        href: WHO_WE_ARE,
        name: "Who We Are"
    },
    {
        href: OUR_SERVICES,
        name: "What We Do"
    },
    {
        href: BLOG,
        name: "Blog"
    },
    {
        href: GET_IN_TOUCH,
        name: "Get In Touch"
    }, 
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);


/***/ })

};
;