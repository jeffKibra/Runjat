"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2317);





function Toasts(props) {
    const { infoMsg , successMsg , errorMsg , warningMsg , title , toastInfo , toastWarning , toastError , toastSuccess ,  } = props;
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    // console.log({ props });
    //info
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (infoMsg) {
            toast({
                duration: 5000,
                isClosable: true,
                position: "top",
                status: "info",
                variant: "subtle",
                ...title ? {
                    title
                } : {},
                description: infoMsg,
                onCloseComplete: ()=>toastInfo(null)
            });
        }
    }, [
        toast,
        infoMsg,
        title,
        toastInfo
    ]);
    //success
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (successMsg) {
            toast({
                duration: 5000,
                isClosable: true,
                position: "top",
                status: "success",
                variant: "subtle",
                ...title ? {
                    title
                } : {},
                description: successMsg,
                onCloseComplete: ()=>toastSuccess(null)
            });
        }
    }, [
        toast,
        successMsg,
        title,
        toastSuccess
    ]);
    //error
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (errorMsg) {
            toast({
                duration: 5000,
                isClosable: true,
                position: "top",
                status: "error",
                variant: "subtle",
                ...title ? {
                    title
                } : {},
                description: errorMsg,
                onCloseComplete: ()=>toastError(null)
            });
        }
    }, [
        toast,
        errorMsg,
        title,
        toastError
    ]);
    //warning
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (warningMsg) {
            toast({
                duration: 5000,
                isClosable: true,
                position: "top",
                status: "warning",
                variant: "subtle",
                ...title ? {
                    title
                } : {},
                description: warningMsg,
                onCloseComplete: ()=>toastWarning(null)
            });
        }
    }, [
        toast,
        warningMsg,
        title,
        toastWarning
    ]);
    return null;
}
Toasts.propTypes = {
    errorMsg: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node),
    infoMsg: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node),
    successMsg: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node),
    warningMsg: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node),
    title: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node)
};
function mapStateToProps(state) {
    const { info: info1 , warning: warning1 , error: error1 , success: success1  } = state.toastReducer;
    return {
        infoMsg: info1,
        warningMsg: warning1,
        errorMsg: error1,
        successMsg: success1
    };
}
function mapDispatchToProps(dispatch) {
    return {
        toastError: (message)=>dispatch((0,_store_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .error */ .vU)(message))
        ,
        toastInfo: (message)=>dispatch((0,_store_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .info */ .um)(message))
        ,
        toastSuccess: (message)=>dispatch((0,_store_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .success */ .Vp)(message))
        ,
        toastWarning: (message)=>dispatch((0,_store_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .warning */ .Kp)(message))
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_3__.connect)(mapStateToProps, mapDispatchToProps)(Toasts));


/***/ }),

/***/ 5682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "db": () => (/* binding */ db)
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// import { getAnalytics, isSupported } from "firebase/analytics";
const firebaseConfig = {
    apiKey: "AIzaSyBxuaL5LfExvMrPj_hcBQZtg6gGnZ4GAcc",
    authDomain: "finitecr-blogs.firebaseapp.com",
    projectId: "finitecr-blogs",
    storageBucket: "finitecr-blogs.appspot.com",
    messagingSenderId: "601844151897",
    appId: "1:601844151897:web:b2acb95c8c25959be96348",
    measurementId: "G-Z3F7TFRRYW"
};
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore)(app); // const isWeb = await isSupported();
 // let analytics_ = null;
 // if (isWeb) {
 //   analytics_ = getAnalytics(app);
 // }
 // export const analytics = analytics_;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1367);
/* harmony import */ var _components_ui_Toasts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5971);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store__WEBPACK_IMPORTED_MODULE_3__]);
_store__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





//css



const styles = {
    global: (props)=>{
        console.log({
            props
        });
        return {
            body: {
                fontFamily: "body",
                color: mode("gray.800", "whiteAlpha.900")(props),
                bg: mode("black", "black")(props),
                lineHeight: "base"
            },
            "*::placeholder": {
                color: mode("gray.400", "whiteAlpha.400")(props)
            },
            "*, *::before, &::after": {
                borderColor: mode("gray.200", "whiteAlpha.300")(props),
                wordWrap: "break-word"
            }
        };
    }
};
const config = (theme1)=>{
    console.log({
        theme: theme1
    });
    return {
        initialColorMode: "dark",
        useSystemColorMode: false
    };
};
const theme = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.extendTheme)({
    config,
    styles
});
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {
        store: _store__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
            theme: theme,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.CSSReset, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Toasts__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1367:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_saga__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6537);
/* harmony import */ var redux_saga__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_saga__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _slices_contactSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(754);
/* harmony import */ var _slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2487);
/* harmony import */ var _slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2317);
/* harmony import */ var _sagas__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8786);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sagas__WEBPACK_IMPORTED_MODULE_5__]);
_sagas__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const sagaMiddleware = redux_saga__WEBPACK_IMPORTED_MODULE_1___default()();
const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        contactReducer: _slices_contactSlice__WEBPACK_IMPORTED_MODULE_2__/* .contactReducer */ .C9,
        commentsReducer: _slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .commentsReducer */ .EG,
        toastReducer: _slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .toastReducer */ .aU
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: false,
            thunk: false
        }).concat(sagaMiddleware)
});
sagaMiddleware.run(_sagas__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ watchCreateComment),
/* harmony export */   "y": () => (/* binding */ watchGetRecentComments)
/* harmony export */ });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
/* harmony import */ var _constants_firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5682);
/* harmony import */ var _slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2487);
/* harmony import */ var _slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2317);
/* harmony import */ var _actions_comments__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5098);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, _constants_firebase__WEBPACK_IMPORTED_MODULE_2__]);
([firebase_firestore__WEBPACK_IMPORTED_MODULE_1__, _constants_firebase__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function* createComment({ data  }) {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .start */ .BL)(_actions_comments__WEBPACK_IMPORTED_MODULE_5__/* .CREATE_COMMENT */ .f));
    //   console.log({ data });
    const { blogId , articleId  } = data;
    async function create() {
        await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.addDoc)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_2__.db, "blogs", blogId, "articles", articleId, "comments"), {
            ...data,
            status: "pending",
            createdAt: (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.serverTimestamp)(),
            modifiedAt: (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.serverTimestamp)()
        });
    }
    try {
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(create);
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .success */ .Vp)());
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .success */ .Vp)("Comment successfully submitted!"));
    } catch (error) {
        console.log(error);
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .fail */ .bG)(error));
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .error */ .vU)(error.message));
    }
}
function* watchCreateComment() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_actions_comments__WEBPACK_IMPORTED_MODULE_5__/* .CREATE_COMMENT */ .f, createComment);
}
function* getRecentComments({ data  }) {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .start */ .BL)(_actions_comments__WEBPACK_IMPORTED_MODULE_5__/* .GET_RECENT_COMMENTS */ .m));
    console.log({
        data
    });
    const { blogId , articleId  } = data;
    async function get() {
        const q = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.collection)(_constants_firebase__WEBPACK_IMPORTED_MODULE_2__.db, "blogs", blogId, "articles", articleId, "comments"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.orderBy)("createdAt", "desc"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.where)("status", "==", "active"));
        const snap = await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocs)(q);
        const comments = [];
        snap.forEach((commentDoc)=>{
            comments.push({
                ...commentDoc.data(),
                id: commentDoc.id
            });
        });
        return comments;
    }
    try {
        const comments = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(get);
        console.log({
            comments
        });
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .commentsSuccess */ .H5)(comments));
    } catch (error) {
        console.log(error);
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_commentsSlice__WEBPACK_IMPORTED_MODULE_3__/* .fail */ .bG)(error));
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_toastSlice__WEBPACK_IMPORTED_MODULE_4__/* .error */ .vU)(error.message));
    }
}
function* watchGetRecentComments() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_actions_comments__WEBPACK_IMPORTED_MODULE_5__/* .GET_RECENT_COMMENTS */ .m, getRecentComments);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ watchSendEmail)
/* harmony export */ });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _actions_contact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3359);
/* harmony import */ var _slices_contactSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(754);



function* sendEmail({ data  }) {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_contactSlice__WEBPACK_IMPORTED_MODULE_1__/* .start */ .BL)());
    // console.log({ data });
    function send() {
        // console.log("sent");
        return fetch("/api/sendmail", {
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json"
            },
            method: "POST"
        }).then((resp)=>{
            // console.log({ code: resp.status, status: resp.statusText });
            if (resp.status === 200) {
                return resp.json();
            } else {
                throw new Error("Data not submitted! Please try again later!");
            }
        }).then((res)=>{
            console.log({
                res
            });
            return res;
        });
    }
    try {
        const response = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(send);
        // console.log({ response });
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_contactSlice__WEBPACK_IMPORTED_MODULE_1__/* .success */ .Vp)());
    } catch (error) {
        console.log(error);
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_slices_contactSlice__WEBPACK_IMPORTED_MODULE_1__/* .fail */ .bG)(error));
    }
}
function* watchSendEmail() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_actions_contact__WEBPACK_IMPORTED_MODULE_2__/* .SEND_EMAIL */ .q, sendEmail);
}


/***/ }),

/***/ 8786:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ rootSaga)
/* harmony export */ });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contactSagas__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2334);
/* harmony import */ var _commentsSagas__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8092);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_commentsSagas__WEBPACK_IMPORTED_MODULE_2__]);
_commentsSagas__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function* rootSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        (0,_contactSagas__WEBPACK_IMPORTED_MODULE_1__/* .watchSendEmail */ .v)(),
        (0,_commentsSagas__WEBPACK_IMPORTED_MODULE_2__/* .watchCreateComment */ .v)(),
        (0,_commentsSagas__WEBPACK_IMPORTED_MODULE_2__/* .watchGetRecentComments */ .y)()
    ]);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "um": () => (/* binding */ info),
/* harmony export */   "Kp": () => (/* binding */ warning),
/* harmony export */   "Vp": () => (/* binding */ success),
/* harmony export */   "vU": () => (/* binding */ error),
/* harmony export */   "aU": () => (/* binding */ toastReducer)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    info: false,
    warning: false,
    success: false,
    error: false
};
const toastSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "toast_slice",
    initialState: {
        ...initialState
    },
    reducers: {
        info: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                info: payload
            };
        },
        warning: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                warning: payload
            };
        },
        success: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                success: payload
            };
        },
        error: (state, action)=>{
            const { payload  } = action;
            return {
                ...state,
                error: payload
            };
        }
    }
});
const { info , warning , success , error  } = toastSlice.actions;
const toastReducer = toastSlice.reducer;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (toastSlice)));


/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6537:
/***/ ((module) => {

module.exports = require("redux-saga");

/***/ }),

/***/ 6477:
/***/ ((module) => {

module.exports = require("redux-saga/effects");

/***/ }),

/***/ 3745:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 1492:
/***/ ((module) => {

module.exports = import("firebase/firestore");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [161,225], () => (__webpack_exec__(8484)));
module.exports = __webpack_exports__;

})();