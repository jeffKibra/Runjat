"use strict";
(() => {
var exports = {};
exports.id = 424;
exports.ids = [424];
exports.modules = {

/***/ 2097:
/***/ ((module) => {

module.exports = require("handlebars");

/***/ }),

/***/ 99:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 6530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const nodemailer = __webpack_require__(99);
const handlebars = __webpack_require__(2097);
async function handler(req, res) {
    const { name , email , subject , message  } = req.body;
    const source = "<p>name: <b>{{name}}</b></p>" + "<p>email: <b>{{email}}</b></p>" + "<p>subject: <b>{{subject}}</b></p>" + "<p>message: <i>{{message}}</i></p>";
    const template = handlebars.compile(source);
    const html = template({
        name,
        email,
        subject,
        message
    });
    const transporter = nodemailer.createTransport({
        host: "mail.ignatiusfactorhrconsulting.com",
        port: 587,
        secure: false,
        auth: {
            user: "social@ignatiusfactorhrconsulting.com",
            pass: "ignatius@Factor"
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    const options = {
        from: "social@ignatiusfactorhrconsulting.com",
        to: "info@ignatiusfactorhrconsulting.com",
        subject: "Leads",
        html
    };
    try {
        const info = await transporter.sendMail({
            ...options
        });
        console.log("email sent");
        console.log({
            info
        });
        res.status(200).json({
            message: "message delivered successfully!"
        });
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6530));
module.exports = __webpack_exports__;

})();