module.exports = {
  reactStrictMode: true,
  env: {
    BLOG_ID: "qCEU8T48srbT2zBaOE2Q",
  },
  images: {
    domains: ["firebasestorage.googleapis.com"],
  },
};
